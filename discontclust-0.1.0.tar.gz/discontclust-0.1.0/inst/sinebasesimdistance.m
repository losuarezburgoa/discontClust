function [sineBaseDist] = sinebasesimdistance (vec1, vec2)
## -*- texinfo -*- 
## @deftypefn {Main function} {@var{sineBaseDist} =} sinebasesimdistance 
##    (@var{vec1}, @var{vec2})
##
## Calculates the sine-based similarity distance between two points, 
## prepresented by two (3 x 1) vectors.
## The @dfn{sine-based similarity measure distance} is defined by 
## d = 1 - (v_1 \cdot v_2)^2.
##
## This distance is a one that is used as measure for the fuzzy K-means 
## algorithm. For more details see Hammah & Curran (1999).
##
## Reference(s):
## R.E. Hammah and J.H. Curran , 1999. On distance measures for the fuzzy 
## K-means algoritm for joint data. Rock Mechanics and Rock Engineering, 
## Vol.32(1): 1-27. @uref{https://doi.org/10.1007/s006030050041}
##
## Author: Ludger O. Suarez-Burgoa @email{losuarezb@@unal.edu.co}
## Created: 2018-05-29
##
## @end deftypefn

sineBaseDist = 1 - (dot(vec1', vec2))^2;
endfunction

## Copyright (C) 2018 Ludger O. Suarez-Burgoa & Universidad Nacional de Colombia.
## 
## This program is free software; redistribution and use in source and
## binary forms, with or without modification, are permitted provided that
## the following conditions are met:
## 
##    1.Redistributions of source code must retain the above copyright
##      notice, this list of conditions and the following disclaimer.
##    2.Redistributions in binary form must reproduce the above copyright
##      notice, this list of conditions and the following disclaimer in the
##      documentation and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
## IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
## ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
## FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
## DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
## OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
## HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
## LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
## OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
## SUCH DAMAGE.
