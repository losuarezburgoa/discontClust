function [pltfig] = plot3dudata (knNormEigVecCell, lCell, symbolSize, ...
    viewVec, kSymbCell)

## -*- texinfo -*- 
## @deftypefn {DiscontClust function} {@var{pltfig} =} plot3dudata ...
##    (@var{knNormEigVecCell}, @var{lCell}, @var{symbolSize}, @var{viewVec}, 
##     @var{kSymbCell})
##
## Input(s):
## @var{knNormEigVecCell}, a (a x K) cell containing the eigen vectors.
## @var{lCell}, a (1 x K) cell that contains the centers of the clusters obtaiend
## by the kmeans statistical method.
## @var{symbolSize}, a natural number that defines the size in pt of the symbols 
## in the plot.
## @var{viewVec}, a (1 x 2) vector that contains the point of view of the 3D 
## plot; same as used in the function @code{view}; by dafault is [30, 20].
## @var{kSymbCell}, a (1 x 3) cell with string that defines the symbols of each
## K cluster; By default is @{ 'o', 'x', '^' @}.
##
## Output(s):
## @var{pltfig} is a figure handle that contains all the plot.
##
## Author: Ludger O. Suarez-Burgoa @email{losuarezb@@unal.edu.co}
## Created: 2018-06-03
##
## @end deftypefn

K = length (knNormEigVecCell);
if K ~= 3
    error ('This plot is only for three dimensions!');
endif

if nargin < 3
    symbolSize = 5;
    viewVec = [30, 20];
    kSymbCell = {'o', 'x', '^'};
elseif nargin < 4
    viewVec = [30, 20];
    kSymbCell = {'o', 'x', '^'};
else
    kSymbCell = {'o', 'x', '^'};
endif

kNameCell = cell(1, K);
for i = 1 : K
  kNameCell{i} = sprintf ('Cluster %d', i);
endfor

cent = zeros(K);
for i = 1  : K
  cent = lCell{i}(2,:);
endfor

stringKwarks = '';
for i = 1 : K
  stringKwarks = strcat (stringKwarks, sprintf(', ''%s''', kNameCell{i}));
endfor

uNameCell = cell(1, K);
for i = 1 : K
  uNameCell{i} = sprintf ('U_%d', i);
endfor

pltWinTitle = ['Clusters in the transformed ', sprintf('K^%d', K), 'space.'];
pltfig = figure('Color', ones(1,3), 'Name', pltWinTitle, 'NumberTitle', 'off'); hold on

h(1) = plot3 (knNormEigVecCell{1}(:,1), knNormEigVecCell{1}(:,2), knNormEigVecCell{1}(:,3), 'color', 'k', kSymbCell{1}, 'MarkerSize', symbolSize);
h(2) = plot3 (knNormEigVecCell{2}(:,1), knNormEigVecCell{2}(:,2), knNormEigVecCell{2}(:,3), 'color', 'k', kSymbCell{2}, 'MarkerSize', symbolSize);
h(3) = plot3 (knNormEigVecCell{3}(:,1), knNormEigVecCell{3}(:,2), knNormEigVecCell{3}(:,3), 'color', 'k', kSymbCell{3}, 'MarkerSize', symbolSize);
h(4) = plot3 (cent(:,1), cent(:,2), cent(:,3), 'rp', 'MarkerSize', 1.5*symbolSize, 'MarkerFaceColor', 'r');
for i = 1 : K
  plot3 (lCell{i}(:,1), lCell{i}(:,2), lCell{i}(:,3), 'k-');
endfor
view(viewVec);
hn2Eval = sprintf('legendHandle = legend(h %s, ''Centers'');', stringKwarks);
eval(hn2Eval);
set(legendHandle, 'Box', 'off');
set(legendHandle, 'Color', 'none');
xlabel(uNameCell{1});
ylabel(uNameCell{2});
zlabel(uNameCell{3});

axis equal
hold off

endfunction

## Copyright (C) 2018 Ludger O. Suarez-Burgoa & Universidad Nacional de Colombia.
## 
## This program is free software; redistribution and use in source and
## binary forms, with or without modification, are permitted provided that
## the following conditions are met:
## 
##    1.Redistributions of source code must retain the above copyright
##      notice, this list of conditions and the following disclaimer.
##    2.Redistributions in binary form must reproduce the above copyright
##      notice, this list of conditions and the following disclaimer in the
##      documentation and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
## IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
## ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
## FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
## DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
## OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
## HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
## LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
## OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
## SUCH DAMAGE.
