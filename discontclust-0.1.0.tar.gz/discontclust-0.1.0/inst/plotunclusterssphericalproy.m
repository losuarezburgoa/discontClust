function [pltfig] = plotunclusterssphericalproy (trendPlungeArray, ...
    projectionType, symbolSize, polargridTrue)

## -*- texinfo -*- 
## @deftypefn {DiscontClust function} {@var{pltfig} =} plotunclusterssphericalproy 
## (@var{trendPlungeArray}, @var{projectionType}, @var{symbolSize}, @var{polargridTrue})
##
## Plot the unclustered data stored in the @var{trendPlungeArray} in a specified
## spherical projection. By default is used the equalarea spherical projection.
## spherical projection and does not plots the grid. Returns a figure handle that
## can be manipulated by the user.
##
## Input(s):
## @var{trendPlungeArray}, is a (n x 2) array that represent in the first column
## the trend angle, and in the second column the plunge angle.
## @var{projectionType} , is a string specifying the type of projection you want
## to plot, can be 'equalarea' or 'equalangle'.
## @var{symbolSize} is an interger in pt units of the size of the symbols in 
## the plot;  by default is of size 5.
## @var{polargridTrue}, is a boolean value if true plots the polar grid in the 
## plot. By default is false.
##
## Output(s):
## @var{pltfig} is a figure handle that contains all the plot.
##
## Author: Ludger O. Suarez-Burgoa @email{losuarezb@@unal.edu.co}
## Created: 2018-06-01
##
## @end deftypefn

## Input management, default values.
if nargin < 2
  projectionType = 'equalarea';
  symbolSize = 5;
  polargridTrue = false;
elseif nargin < 3
  symbolSize = 5;
  polargridTrue = false;
elseif nargin < 4
  polargridTrue = false;
end

## Plotting the data in the select spherical projection.
pltWinTitle = ['Unclustered data in ', projectionType, '.'];

pltfig = figure('Color', ones(1,3), 'Name', pltWinTitle, 'NumberTitle', 'off');
hold on
plotplaneorientationdata (trendPlungeArray, projectionType, 's', false, symbolSize);
if polargridTrue == true
    createpolargrid (projectionType);
endif
plotgreatcircnorth (projectionType);
axis equal
hold off

endfunction

## Copyright (C) 2013, 2018 Ludger O. Suarez-Burgoa & Universidad Nacional de Colombia.
## 
## This program is free software; redistribution and use in source and
## binary forms, with or without modification, are permitted provided that
## the following conditions are met:
## 
##    1.Redistributions of source code must retain the above copyright
##      notice, this list of conditions and the following disclaimer.
##    2.Redistributions in binary form must reproduce the above copyright
##      notice, this list of conditions and the following disclaimer in the
##      documentation and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
## IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
## ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
## FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
## DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
## OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
## HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
## LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
## OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
## SUCH DAMAGE.
