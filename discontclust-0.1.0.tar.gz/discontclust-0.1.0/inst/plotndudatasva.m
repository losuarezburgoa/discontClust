function [] = plotndudatasva (knNormEigVecCell, lCell, symbolSize)

## -*- texinfo -*- 
## @deftypefn {DiscontClust function} {@var{[]} =} plotndudatasva (@var{knNormEigVecCell},
##   @var{lCell}, @var{symbolSize})
##
## Description:
## For more than the three dimensions, it plots a CVA biplot under a Canonical 
## Variate Analysis (CVA); which is a biplot used in clustered data.
## See Gower.etal2011.book for more details (Chapter 4, page 145).
## The number of clusteres (number of dimension) to be displayed is limited to
## ten only, because more clusteres could be uncesessarily detailed.
##
## Input(s):
## @var{knNormEigVecCell}, a (a x K) cell containing the eigen vectors.
## @var{lCell}, a (1 x K) cell that contains the centers of the clusters obtaiend
## by the kmeans statistical method.
## @var{symbolSize}, a natural number that defines the size in pt of the symbols 
## in the plot.
##
## Author: Ludger O. Suarez-Burgoa @email{losuarezb@@unal.edu.co}
## Created: 2018-06-03
##
## @end deftypefn

display('Plot in K^n with n other than 2 or 3 is not presented!');
display('I will develop the proper tool for displaying clustered data in K^n.');
        
% This is under development.
% I will use bi-plots, which is a generalization of the scatterplot 
% of two variables to the case of many variables.

if nargin < 3
  symbolSize = 5;
end

K = length(knNormEigVecCell);
if and (K <= 1, K > 10)
  error ('The dimension K should be greater than 1 and less than 11!');
endif

cent = zeros(K);
for i = 1  : K
  cent = lCell{i}(2,:);
endfor

kSymbCell = {'o', 'x', '^', '+', 'v', '.', '<', 'd', '>', '*'};
kNameCell = cell(1, K);
for i = 1 : K
  kNameCell{i} = sprintf ('Cluster %d', i);
endfor

stringKwarks = '';
for i = 1 : K
  stringKwarks = strcat (stringKwarks, sprintf(', ''%s''', kNameCell{i}));
endfor

uNameCell = cell(1, K);
for i = 1 : K
  uNameCell{i} = sprintf ('U_%d', i);
endfor

# Plotting for the biplot.
# I will prepare the data in order to be used in a R program for Biplots.
totnumDataVec = zeros(1,K);
for i = 1 : K
    totnumDataVec(i) = size(knNormEigVecCell{i}, 1);
endfor
totnumDataVec = [0, totnumDataVec];

cumsumDataVec = cumsum(totnumDataVec);
A = zeros(cumsumDataVec(end), K+1);

for i = 1 : K
    numData = size(knNormEigVecCell{i}, 1);
    A(cumsumDataVec(i)+1 : cumsumDataVec(i+1), 1) = ones(numData,1) * i;
    A(cumsumDataVec(i)+1 : cumsumDataVec(i+1), 2:K+1) = knNormEigVecCell{i};
endfor
A = [transpose(1:1:sum(totnumDataVec)), A];

totNumData = sum(totnumDataVec);
file_id = fopen('data4R.dat', 'w');
for i = 1 : totNumData
    fdisp(file_id, sprintf('%d\t%d\t%.4f\t%.4f\t%.4f\t%.4f', A(i,:)));
endfor
fclose(file_id);

endfunction

## Copyright (C) 2018 Ludger O. Suarez-Burgoa & Universidad Nacional de Colombia.
## 
## This program is free software; redistribution and use in source and
## binary forms, with or without modification, are permitted provided that
## the following conditions are met:
## 
##    1.Redistributions of source code must retain the above copyright
##      notice, this list of conditions and the following disclaimer.
##    2.Redistributions in binary form must reproduce the above copyright
##      notice, this list of conditions and the following disclaimer in the
##      documentation and/or other materials provided with the distribution.
## 
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
## ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
## IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
## ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
## FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
## DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
## OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
## HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
## LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
## OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
## SUCH DAMAGE.
